import { Component } from '@angular/core';

@Component({
  selector: 'app-mask',
  templateUrl: './mask.component.html',
  styleUrl: './mask.component.css'
})
export class MaskComponent {
   salary=1000;
   phone=''
}
