export interface Attendee {
  id?: number;
  name: string;
  guests: number;
  attending: boolean;
}
