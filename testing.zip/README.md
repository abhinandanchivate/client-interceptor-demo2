# ng-mocks examples and guides

Live examples to play with [`ng-mocks`](https://www.npmjs.com/package/ng-mocks)
on [CodeSandbox](https://codesandbox.io/p/sandbox/github/help-me-mom/ng-mocks-sandbox/tree/master/?file=/src/test.spec.ts)
or
on [StackBlitz](https://stackblitz.com/github/help-me-mom/ng-mocks-sandbox?file=src/test.spec.ts).

Documentation is on [ng-mocks.sudo.eu](https://ng-mocks.sudo.eu/).
