import { InjectionToken } from '@angular/core';

export const TOKEN_KEEP = new InjectionToken('TOKEN_KEEP');

export const TOKEN_MOCK = new InjectionToken('TOKEN_MOCK');

export const TOKEN_CUSTOMIZE = new InjectionToken('TOKEN_CUSTOMIZE');
