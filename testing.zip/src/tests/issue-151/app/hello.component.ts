import { Component } from '@angular/core';

@Component({
  selector: 'hello-151',
  template: 'hello',
})
export class HelloComponent {}
